
package net.mcreator.michaelsmcmod.fuel;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.item.ItemStack;

import net.mcreator.michaelsmcmod.item.HazePowderItem;
import net.mcreator.michaelsmcmod.MichaelsMcModElements;

@MichaelsMcModElements.ModElement.Tag
public class HazepowderfuelFuel extends MichaelsMcModElements.ModElement {
	public HazepowderfuelFuel(MichaelsMcModElements instance) {
		super(instance, 41);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@SubscribeEvent
	public void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == new ItemStack(HazePowderItem.block, (int) (1)).getItem())
			event.setBurnTime(150000);
	}
}
