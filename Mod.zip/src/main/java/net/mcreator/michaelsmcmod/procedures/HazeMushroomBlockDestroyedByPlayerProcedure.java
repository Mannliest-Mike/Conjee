package net.mcreator.michaelsmcmod.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.michaelsmcmod.MichaelsMcModElements;

@MichaelsMcModElements.ModElement.Tag
public class HazeMushroomBlockDestroyedByPlayerProcedure extends MichaelsMcModElements.ModElement {
	public HazeMushroomBlockDestroyedByPlayerProcedure(MichaelsMcModElements instance) {
		super(instance, 32);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure HazeMushroomBlockDestroyedByPlayer!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof PlayerEntity)
			((PlayerEntity) entity).addExperienceLevel(-((int) 1));
		entity.attackEntityFrom(DamageSource.GENERIC, (float) 1);
	}
}
